ballerina
=========

Manage ballerina jars

Requirements
------------

* None

Role Variables
--------------

| Variable | Default value | Description |
| -------- | ------------- | ----------- |
| `ballerina_root` | /var/lib/ | Folder to deploy ballerina dir
| `ballerina_java_version` | 8 | Java version to install

Dependencies
------------

* openjdk
* pm2

Example Playbook
----------------

```yml
- hosts: all
  roles:
    - role: ballerina
      ballerina_data_dir: /var/lib
```

Testing
--------

Launch the test

```bash
pip install molecule molecule[docker]
molecule test
```

[Docs on testing](https://molecule.readthedocs.io)

License
-------

BSD

Author Information
------------------

* Jean-Vincent KASSI <jekas@smile.ci>
