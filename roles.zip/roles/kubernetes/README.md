Kubernetes
=========

This role configure and deploy a kubernetes cluster

Requirements
------------

* 2 GB ram
* 2 CPU

Role Variables
--------------

### Global variables

Variable | Default value | MySQL variable
---------|---------------|--------------
`k8s_version` | 1.24.0 | k8s version
`k8s_apiserver_advertise_address` | `{{ ansible_fqdn }}` | k8s master node hostname or ip address
k8s_control_plane_endpoint
`k8s_pod_network_cidr` | 10.244.0.0/16 | K8s pod networks CIDR
`k8s_slave_nodes` | [] | List FQDN of k8s slave nodes
`k8s_cri_name` | cri-o | Container Runtime interface to use. Support: cri-o, podman, docker
`k8s_reset_cluster` | false | Reset k8s cluster
`k8s_dashboard_hosts` | ['k8s-dashboard.example.com'] | Update hosts dashboard k8s

### Mutli master

This role support cluster node with an external or internal etcd

Variable | Default value | MySQL variable
---------|---------------|--------------
`k8s_master_nodes:` | [`{{ ansible_fqdn }}`] | List **fqdn** of masters nodes
`k8s_control_plane_endpoint` | `{{ k8s_master_nodes[0] }}` | IP Address of control plane. This IP can be a VIP or IP of Load bancer
`k8s_etcd_nodes` | [] | List **fqdn** of **external** etcd nodes
`k8s_etcd_ssl_ca_cert_path` | Root CA of etcd client certificate
`k8s_etcd_ssl_cert_path` |  | Client Certificate file of etcd
`k8s_etcd_ssl_privkey_path` |  | Client Certificate key of etcd

Example:

```yml
---

- hosts: kubernetes
  vars:
    k8s_master_nodes: "{{ groups['k8s-masters'] }}"
    k8s_slave_nodes: "{{ groups['k8s-slaves'] }}"
    # ETCD externe
    # k8s_etcd_hosts: "{{ groups['etcd'] }}"
    # Si ya un certificat sur le ETCD
    # k8s_etcd_ssl_ca_cert_path: /etc/ssl/certs/ca/k8s-ca.pem
    # k8s_etcd_ssl_cert_path: /etc/etcd/client.pem
    # k8s_etcd_ssl_privkey_path: /etc/etcd/client-key.pem
  roles:
    - role: kubernetes

```

### Charts

This role can also install helm charts. Some charts are deployed by defaults  (*vars/main.yml*). Here are the list

* metrics-server
* kubernetes-dashboard
* traefik (ingress controller)

To install a new chart. You can use thoses vars

Variable | Default value | MySQL variable
---------|---------------|--------------
`name` | | Name of the release
`url` | htps://... | K8s pod networks CIDR
`repo` |  | Reference of repo
`config` | {} | Configuration yaml values of the release


Example:

```yml
---

- hosts: all
  roles:
    - role: kubernetes
      k8s_helm_charts:
        - name: metrics-server
          repo: metrics-server/metrics-server
          url: https://kubernetes-sigs.github.io/metrics-server/
          config:
            args:
              - --kubelet-insecure-tls
```

Dependencies
------------

* cri-o

Example Playbook
----------------

Sample playbook file

```yml
  - hosts: kubernetes
    roles:
      - role: kubernetes
        k8s_master_nodes: ["{{ master_node }}"]
        k8s_slave_nodes: "{{ groups['k8s_slaves'] }}"
        k8s_dashboard_hosts: ['k8s-dashboard.example.com']
```

License
-------

BSD

Author Information
------------------

* Jean-Vincent KASSI <jekas@smile.ci>
