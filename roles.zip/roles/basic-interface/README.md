basic-interface
=========

This role permit to manage server network interfaces

Requirements
------------

None

Role Variables
--------------

Variable | Default value |Description
---------|---------------|--------------
`rename_interfaces` | {} | List of interfaces to rename
`network_interfaces` | {} | List of the interfaces to configure
`network_bridges` | {} | List of the bridges to configure
`network_service` | `network`|`NetworkManager` | network service to be used (default for EL7 network / default for EL8 NetworkManager)
`generate_udev` | `false` | Force udev file 70-persistent-net.rules regeneration


Network interface variables:

Variable                  | Default value |Description
--------------------------|---------------|--------------
`network_interfaces.name` |               | Interface name to configure
`network_interfaces.ip4`  |               | IPv4 address to assign to interface in CIDR format (ex: 10.1.2.15/24)
`network_interfaces.ip6`  | (optional)    | IPv6 address to assign to interface in CIDR format (ex: fd02:cdef:1:2::1/64)
`network_interfaces.zone` | (optional)    | Firewalld zone where interface need to be affected
`network_interfaces.vlan` | (optional)    | VLAN ID to assign to interface

Network bridge variables:

Variable               | Default value |Description
-----------------------|---------------|--------------
`network_bridges.name` |               | Bridge name
`network_bridges.netif`|               | Physical interface to attach to bridge
`network_bridges.ip4`  |               | IPv4 address to assign to bridge in CIDR format (ex: 10.1.2.15/24)
`network_bridges.ip6`  | (optional)    | IPv6 address to assign to bridge in CIDR format (ex: fd02:cdef:1:2::1/64)
`network_bridges.zone` | (optional)    | Firewalld zone where interface need to be affected
`network_bridges.vlan` | (optional)    | VLAN ID to assign to interface


Dependencies
------------

None

Example Playbook
----------------

Rename interface

```yml
- hosts: all
  roles:
    - role: basic-interface
      rename_interfaces:
        eth0: adm
        eth1: data
```

Assign interface

```yml
- hosts: all
  roles:
    - role: basic-interface
      network_interfaces:
        - name: data
          ip4: 192.168.1.1/24
```

Create simple bridge:

```yml
- hosts: all
  roles:
    - role: basic-interface
      network_bridges:
        - name: private
          netif: eth0
          ip4: 192.168.1.16/24
```

Create bridge with IPv6, VLAN ID and associate it to **internal** firewalld zone:

```yml
- hosts: all
  roles:
    - role: basic-interface
      network_bridges:
        - name: private
          netif: eth0
          ip4: 192.168.1.16/24
          ip6: fd02:cdef:1:2::1/64
          vlan: 12
          zone: internal
```

License
-------

BSD

Author Information
------------------

* Jean-Vincent KASSI <jekas@smile.ci>
