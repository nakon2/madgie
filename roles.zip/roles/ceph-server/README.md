Role Name
=========

Install and configure ceph server 

Requirements
------------

* ntp
* basic-user

Role Variables
--------------

| Variable | Default value | Description |
| -------- | ------------- | ----------- |
| `ceph_hosts` | [] | All current servers in the playbooks | 
| `ceph_version` | quicny | Ceph version to use |
| `ceph_cluster_name` | ceph | Ceph cluster name |
| `ceph_fs_enable` | false | Disable / Enable ceph fs |
| `ceph_radgw_enable` | false | Disable / Enable ceph radgw | 
| `ceph_rbd_enable` | false | Disable / Enable ceph rbd |
| `ceph_backup_dir` | /var/backup/ceph | Ceph backup dir |
| `ceph_enable_monitoring` | true | Ceph enable monitoring | 
| `ceph_enable_firewalld` | true | Firewalld | 
| `ceph_osd_devices` | [] | Ceph OSD Devices |
| `ceph_rgws` | [] | List of ceph rgws |
| `ceph_cephfs` | [] | List of cephfs volumes |

Dependencies
------------

* None

Example Playbook
----------------

```yaml

- hosts: servers
  vars:
    ceph_hosts: "{{ play_hosts }}"
    ceph_osd_devices:
      - /dev/vdb
    ceph_rbd_pools:
      - data
    ceph_rgws: []
    ceph_cephfs: []
  roles:
      - role: ceph-server
```

License
-------

BSD

Author Information
------------------

An optional section for the role authors to include contact information, or a website (HTML is not allowed).
