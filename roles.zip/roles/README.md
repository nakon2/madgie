Ansible Roles
=========

This master project group all Smile CI ansible roles as Git sub-modules.

No role shoud be created directly in this project. New roles must be defined by creating a new project in GitLab group https://git.smile.ci/adminsys/ansible/role and reference as sub-module in this project.

Step to create new role :
  - Create new project in https://git.smile.ci/adminsys/ansible/role/$ROLE_NAME
  - Reference as submodule in /etc/ansible/roles/ :

```
export ROLE_NAME=your_role_name
git submodule add git@git.smile.ci:adminsys/ansible/role/${ROLE_NAME}.git
ansible-galaxy init -f $ROLE_NAME
cd $ROLE_NAME
git add .
git commit -m "Initial commit"
git push -u origin master
git tag -a v0.1.0 -m "Initial commit"
git push origin v0.1.0
```

Add $ROLE_NAME submodule in .gitmodules file and push modification to git.

```
git commit -m "Add $ROLE_NAME in .gitmodules" .gitmodules && git push
```


Role compatibility
--------------

Role Name | CentOS 7 | Rocky 8 | Rocky 9 |
----------|----------|----------|-------|
activemq | OK |
alfresco | OK |
ambari-agent | OK |
ambari-server | OK |
ansistrano | OK | OK
apache | OK | OK
apache-proxy | OK | OK
apm-elastic | OK | OK
asterisk | OK |
auditbeat | OK | OK
autofs | OK |
bacula-agent | OK | OK
bacula-director | OK | OK
bacula-storage | OK | OK
basic-disk | OK |  OK
basic-firewalld | OK | OK
basic-interface | OK | OK
basic-route | OK | OK
basic-server | OK | OK
basic-user | OK | OK
bind | OK | OK
brms | OK |
cassandra | OK |
centreon-agent | OK | OK
centreon-poller | OK | OK
centreon-prov | OK | OK
centreon-server | OK |
ceph-client | OK | OK
ceph-server | OK |
cerebro | OK |
composer | OK |
confd | OK |
coturn | OK |
csync2-lsyncd | OK | OK
debian-backports | OK |
docker | OK | OK
docker-swarm | OK | OK
drbd | OK | OK
drupal | OK |
elastic | OK | OK
elastic-apm | OK | OK
elasticsearch | OK | OK
erlang | OK |
etcd | OK |
etherpad | OK |
fail2ban | OK | OK
filebeat | OK | OK
flywaydb | OK |
foreman | OK |  OK
foreman-init | OK |
freeipa-client | OK | OK
freeipa-server | OK | OK
freeradius | OK | OK
freeradius-mysql | OK | OK
freeradius-proxy | OK |
generic-service | OK |
generic-webapp | OK |
genieacs | OK |
genieacs-gui | OK |
gitlab-runner | OK |
gitlab-server | OK |
glassfish | OK |
hadoop | OK |
haproxy | OK | OK
hbase | OK |
ioncube | OK |
ipsec | OK |
jitsi-jibri | OK |
jitsi-jicofo | OK |
jitsi-jigasi | OK |
jitsi-meet | OK |
jitsi-videobridge | OK |
kafka | OK | OK
katello-agent | OK |  OK
keepalived | OK |
keycloak | OK |
kibana | OK | OK
kubernetes | OK |
ldap-user | OK |
letsencrypt | OK |
libvirt-kvm | OK | OK
logstash | OK | OK
lua | OK |
mariadb-galera-cluster | OK | OK
mariadb-server | OK | OK
memcached | OK |
metricbeat | OK | OK
mongodb | OK |
mule-esb | OK |
mysql-provider | OK | OK
neo4j | OK |
newrelic-daemon | OK |
newrelic-php-agent | OK |
nextcloud | OK | OK
nfs-client | OK | OK
nfs-server | OK | OK
nginx | OK |
nodejs | OK |
ntp | OK |
odoo | OK |
ogo-proxy | OK | OK
openjdk | OK | OK
openldap | OK |
openstreetmap | OK |
oracle-java | OK | NA
owncloud | OK |
pacemaker | OK | OK
packetbeat | OK | OK
php | OK | OK
php-fpm | OK |
phpipam | OK | OK
phpmyadmin | OK |
pmm-client | OK | OK
podman | OK |
postfix | OK | OK
postgresql | OK |
postgresql-provider | OK |
postgresql-server | OK |
privacy-idea | OK |
proftpd | OK |
prosody | OK |
python | OK |
rabbitmq | OK |
redis | OK | OK
rocketchat | OK |
rspamd | OK |
ruby | OK |
rundeck | OK | OK
scala | OK |
security | OK | OK
security-apache | OK | OK
security-mariadb | OK | OK
security-php | OK | OK
skeleton | OK |
smokeping | OK |
snmp | OK |  OK
solr | OK |
sonarqube | OK |
spagobi | OK |
spark | OK |
ssl-certs | OK |
symfony | OK |
tomcat | OK | OK
traefik | OK | OK
trafficserver | OK |
vagrant | OK | OK
varnish | OK |
webacula | OK | OK
webmin | OK |
wekan | OK |
whmcs | OK | OK
wso2am | OK |
wso2as | OK |
wso2bp | OK |
wso2ei | OK |
wso2-generic | OK |
wso2iot | OK |
wso2is | OK |
wso2sp | OK |
zeppelin | OK |
zimbra | OK | OK
zookeeper | OK | OK
zpush | OK | OK
