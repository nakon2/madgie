cloudstack-provider
=========

Adminsys

Requirements
------------

Any pre-requisites that may not be covered by Ansible itself or the role should be mentioned here. For instance, if the role uses the EC2 module, it may be a good idea to mention in this section that the boto package is required.

Role Variables
--------------

A description of the settable variables for this role should go here, including any variables that are in defaults/main.yml, vars/main.yml, and any variables that can/should be set via parameters to the role. Any variables that are read from other roles and/or the global scope (ie. hostvars, group vars, etc.) should be mentioned here as well.

- `cs_api_url`: The URL of the CloudStack API.
- `cs_api_key`: The API access key for CloudStack.
- `cs_api_secret`: The API access secret for CloudStack.
- `cs_vms`: An array containing specifications of instances to create. Each element of the array should have the following sub-elements:
  - `name`: The name of the instance.
  - `iso_name`: The name of the ISO to use for the instance.
  - `service_offering`: The service offering to use for the instance.
  - `zone`: The zone in which to create the instance.
  - `network`: The name of the network to connect the instance to.
  - `disk_offering`: The disk offering to use for the instance.
  - `hypervisor`: The hypervisor to use for the instance.

Dependencies
------------

A list of other roles hosted on Galaxy should go here, plus any details in regards to parameters that may need to be set for other roles, or variables that are used from other roles.

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

```yml
- hosts: servers
  roles:
    - role: cloudstack-provider
      vars:
        cs_api_url: "https://cloudstack.example.com/client/api"
        cs_api_key: "your_api_key"
        cs_api_secret: "your_api_secret"
        cs_vms:
          - name: rodje2
            iso_name: "Rocky Linux 8 ISO"
            template_name: "rocky8"
            service_offering: "Small Instance"
            zone: "synelia"
            network: "net1"
            disk_offering: "Small"
            hypervisor: "kvm"
          - name: rodje3
            iso_name: "Ubuntu 20.04 ISO"
            service_offering: "Medium Instance"
            zone: "another_zone"
            network: "net2"
            disk_offering: "Medium"
            hypervisor: "xen"

```

NB: You have to use iso_name if you want to use an iso or template_name if you want to use an existing template

Testing
--------

Launch the test

```bash
pip install molecule molecule[docker]
molecule test
```

[Docs on testing](https://molecule.readthedocs.io)

License
-------

BSD

Author Information
------------------

* Romaric DJEMBER <romaric.djember@synelia.tech>
