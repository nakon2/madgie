def bool_to_yes_no(value):
    if isinstance(value, bool):
        return 'yes' if value else 'no'
    return value

class FilterModule(object):
    def filters(self):
        return {'bool_to_yes_no': bool_to_yes_no}