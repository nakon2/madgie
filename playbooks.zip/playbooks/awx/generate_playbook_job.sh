#!/bin/bash


FILE=ansible-launch-playbooks.yml

rm $FILE
echo '---' | tee  $FILE

#for playbook in `find .. -maxdepth 1 ! -type l -type f -name "*yml" | grep -v cluster | grep -v basic | grep -v user | sort -n`
for playbook in `ls -1 playbooks`
do
  playbook=$(basename $playbook | cut -d . -f 1) 
  echo "- import_playbook: ../${playbook}.yml" | tee -a  $FILE
  echo "  when: \"'${playbook}' in playbooks.split(',')\"" | tee -a $FILE
done
  
 
